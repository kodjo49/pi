const LOCK = function () {
    let panel;

    return {
        state: false,
        init: function () {
            let self = this;
            setTimeout(function () {
                self.loading();
                setTimeout(function () {
                    self.unlock();
                    self.lock();
                }, 6500)
            }, 200);
            window.oncontextmenu = function () {
                return false;
            };
        },
        lock: function () {
            let self = this;
            self.state = true;
            panel = jsPanel.modal.create({
                contentSize: '260 31',
                border: 'transparent',
                header: false,
                closeOnBackdrop: false, // see notes below
                closeOnEscape: false,
                content:
                    '<div style="background-color: transparent;">' +
                    '  <input style="width: 100%" type="password" placeholder="password" value="">' +
                    '</div>',
                callback: function () {
                    let input = this.content.querySelectorAll('input')[0];
                    input.focus();
                    input.addEventListener('keyup', function () {
                        if (this.value === "1234") {
                            panel.close();
                            self.state = false;

                            document.body.addEventListener("keydown", keyDownTextField, false);

                            function keyDownTextField(e) {
                                var keyCode = e.keyCode;
                                if (keyCode === 76 && !self.state) {
                                    self.state = true;
                                    setTimeout(function () {
                                        self.lock();
                                    }, 100);
                                }
                            }
                        }

                    });

                }
            });
        },
        loading: function () {
            panel = jsPanel.modal.create({
                contentSize: 'auto 37',
                border: '#ffc107',
                header: false,
                closeOnBackdrop: false, // see notes below
                closeOnEscape: false,
                content:
                    '<div style="background-color: #0f0f10;overflow: hidden">' +
                    '<div class="spinner-grow text-primary" role="status">\n' +
                    '  <span class="sr-only">Loading...</span>\n' +
                    '</div>\n' +
                    '<div class="spinner-grow text-secondary" role="status">\n' +
                    '  <span class="sr-only">Loading...</span>\n' +
                    '</div>\n' +
                    '<div class="spinner-grow text-success" role="status">\n' +
                    '  <span class="sr-only">Loading...</span>\n' +
                    '</div>\n' +
                    '<div class="spinner-grow text-danger" role="status">\n' +
                    '  <span class="sr-only">Loading...</span>\n' +
                    '</div>\n' +
                    '<div class="spinner-grow text-warning" role="status">\n' +
                    '  <span class="sr-only">Loading...</span>\n' +
                    '</div>\n' +
                    '<div class="spinner-grow text-info" role="status">\n' +
                    '  <span class="sr-only">Loading...</span>\n' +
                    '</div>\n' +
                    '<div class="spinner-grow text-light" role="status">\n' +
                    '  <span class="sr-only">Loading...</span>\n' +
                    '</div>\n' +
                    '<div class="spinner-grow text-dark" role="status">\n' +
                    '  <span class="sr-only">Loading...</span>\n' +
                    '</div>' +
                    '</div>'
            });
        },
        unlock: function () {
            panel.close();
        }
    }
};