$('.ui.dropdown')
    .dropdown({
        on: 'hover',
        allowCategorySelection: true
    });

