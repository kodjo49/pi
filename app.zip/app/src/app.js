$('.ui.dropdown')
    .dropdown({
        on: 'hover'
    });
$('.clearable.example .ui.selection.dropdown')
    .dropdown({
        clearable: true
    })
;
$('.clearable.example .ui.inline.dropdown')
    .dropdown({
        clearable: true,
        placeholder: 'any'
    })
;
menuDropdowns = function () {
    $('.dropdown').each(function () {
        const links = $(this).find('.links');
        const h = links.height();

        links.css('height', '0');

        $(this).click(function () {
            if ($(this).toggleClass('js-opened').hasClass('js-opened')) {
                links.css('height', h);
            } else {
                links.css('height', 0);
            }

        });
    });
};

$(document).ready(function () {

    menuDropdowns();

    $('.js-toggle-menu').click(function () {
        $('.app-menu').toggleClass('active');
    });
});
