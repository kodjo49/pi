STYLE = {
    position: 'fixed',
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
    'z-index': 1000,
    'background': 'black',
    opacity: 1.0,
    transition: 'opacity 2s ease',
};

DEFAULT = {
    position: 'absolute',
    left: '50%',
    top: '50%',
    transform: 'translate(-50%, -50%)',
    width: 'auto',
    height: 'auto',
    color: 'white'
};

/**
 *
 * @param style | background:black
 * @constructor
 */
var Splash = function (style = {}) {
    this.body = document.body;
    this.display = this.body.style.display;
    //this.body.style.display = 'none';

    this.splash = document.createElement("div");
    this.splash.className = "js-splash";

    if (style != null) {
        Object.keys(style).map(function (key, index) {
            STYLE[key] = style[key];
        });
    }

    Object.assign(this.splash.style, STYLE);

    this.__init = function (element, animation_time = 3000, option = {}) {
        let self = this;

        self.body.style.display = 'none';

        if (option != null) {
            Object.keys(option).map(function (key, index) {
                DEFAULT[key] = option[key];
            });
        }

        Object.assign(element.style, DEFAULT);
        this.splash.appendChild(element);

        this.body.appendChild(this.splash);
        self.body.style.display = self.display;

        setTimeout(function () {
            self.splash.addEventListener("transitionend", function () {
                self.splash.style.display = "none";
            }, true);
            // Kick off the CSS transition
            self.splash.style.opacity = 0.0;
            document.body.removeChild(self.splash);
        }, animation_time);
    }
};

/**
 *
 * @param text | string node
 * @param animation_time
 * @param option
 */
Splash.prototype.fromText = function (text, animation_time = 3000, option = {}) {
    let self = this;

    var loader = document.createElement("div");
    loader.innerHTML = text;

    self.__init(loader, animation_time, option);
};

/**
 *
 * @param image => url | base64 => based on html <img>
 * @param animation_time
 * @param option
 */
Splash.prototype.fromImage = function (image, animation_time = 3000, option = {}) {
    let self = this;

    var loader = document.createElement("img");
    loader.src = image;

    self.__init(loader, animation_time, option);
};

/**
 *
 * @param node => Ex: document.createElement('div');
 * @param animation_time
 * @param option
 */
Splash.prototype.fromCustomNode = function (node, animation_time = 3000, option = {}) {
    let self = this;
    self.__init(node, animation_time, option);
};

Splash.prototype.fromCSSAnimation = function (css_file, animation_time = 3000) {
    function loadCss() {
        let head = document.getElementsByTagName('head')[0];
        let style = document.createElement('link');
        style.href = css_file;
        style.type = 'text/css';
        style.rel = 'stylesheet';
        head.append(style);
    }
}